from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pandas as pd
import requests
from langchain_core.tools import tool

DATA_PATH = Path(__file__).resolve().parents[1] / "data" / "olist_order_lookup_sample.csv"


def _safe_error(prefix: str, exc: Exception) -> str:
    """Return an agent-safe error instead of raising."""
    return f"{prefix}: {type(exc).__name__}: {exc}"


@tool
def get_weather(city: str) -> str:
    """Fetch the current weather for a city using the live Open-Meteo API.

    Args:
        city: City name to geocode and query.

    Returns:
        A JSON string containing the resolved location and current weather,
        or an error string if the live request fails.
    """
    try:
        city = city.strip()
        if not city:
            return "ERROR: city must not be empty."

        geo = requests.get(
            "https://geocoding-api.open-meteo.com/v1/search",
            params={"name": city, "count": 1, "language": "en", "format": "json"},
            timeout=10,
        )
        geo.raise_for_status()
        results = geo.json().get("results", [])
        if not results:
            return f"ERROR: no location found for '{city}'."

        place = results[0]
        lat, lon = place["latitude"], place["longitude"]

        weather = requests.get(
            "https://api.open-meteo.com/v1/forecast",
            params={
                "latitude": lat,
                "longitude": lon,
                "current": "temperature_2m,relative_humidity_2m,"
                "apparent_temperature,wind_speed_10m,weather_code",
                "timezone": "auto",
            },
            timeout=10,
        )
        weather.raise_for_status()
        current = weather.json().get("current", {})

        return json.dumps(
            {
                "city": place.get("name", city),
                "country": place.get("country"),
                "latitude": lat,
                "longitude": lon,
                "timezone": weather.json().get("timezone"),
                "current": current,
            },
            ensure_ascii=False,
        )
    except Exception as exc:
        return _safe_error("ERROR: weather lookup failed", exc)


@tool
def lookup_olist_order(order_id: str) -> str:
    """Look up one Olist order in the local read-only sample.

    Args:
        order_id: Exact Olist order identifier.

    Returns:
        Selected order, customer, review, and payment facts as JSON,
        or an error message if the order is not found or data cannot be read.
    """
    try:
        order_id = order_id.strip()
        if not order_id:
            return "ERROR: order_id must not be empty."

        if not DATA_PATH.exists():
            return f"ERROR: local data file not found at {DATA_PATH}."

        df = pd.read_csv(DATA_PATH)
        rows = df[df["order_id"].astype(str) == order_id]

        if rows.empty:
            return json.dumps(
                {"found": False, "order_id": order_id},
                ensure_ascii=False,
            )

        row = rows.iloc[0].where(pd.notna(rows.iloc[0]), None).to_dict()
        return json.dumps({"found": True, "order": row}, ensure_ascii=False)
    except Exception as exc:
        return _safe_error("ERROR: Olist lookup failed", exc)


TOOLS = [get_weather, lookup_olist_order]
