from __future__ import annotations

import argparse
import json
from pathlib import Path

from langchain_core.messages import AIMessage, HumanMessage
from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel

from .agent import PROMPT, TOOLS, build_executor, extract_trace, run_live_query
from .tools import lookup_olist_order
from .workflow import run_both_routes


def sample_order_id() -> str:
    """Return the first order ID from the compact supplied-data sample."""
    result = lookup_olist_order.invoke({"order_id": ""})
    # The tool contract intentionally requires an exact ID, so read the file
    # directly here only to select a demonstration ID; the agent itself uses
    # the tool for the actual lookup.
    import pandas as pd
    from .tools import DATA_PATH
    return str(pd.read_csv(DATA_PATH, usecols=["order_id"]).iloc[0, 0])


def run_mock() -> dict:
    """Run a deterministic framework-level demonstration without Gemini.

    The fake model returns native AIMessage tool_calls, allowing the project
    to verify the exact LangChain tool-call representation without an API key.
    """
    order_id = sample_order_id()

    # Query 1: weather tool.
    model = FakeMessagesListChatModel(
        responses=[
            AIMessage(
                content="",
                tool_calls=[
                    {
                        "name": "get_weather",
                        "args": {"city": "New Delhi"},
                        "id": "mock-weather-1",
                        "type": "tool_call",
                    }
                ],
            ),
            AIMessage(content="I checked the live weather tool and can report it."),
        ]
    )
    from langchain.agents import AgentExecutor, create_tool_calling_agent
    executor = AgentExecutor(
        agent=create_tool_calling_agent(model, TOOLS, PROMPT),
        tools=TOOLS,
        max_iterations=5,
        return_intermediate_steps=True,
    )
    r1 = executor.invoke({"input": "What is the current weather in New Delhi?", "chat_history": []})

    # Query 2: Olist lookup.
    model2 = FakeMessagesListChatModel(
        responses=[
            AIMessage(
                content="",
                tool_calls=[
                    {
                        "name": "lookup_olist_order",
                        "args": {"order_id": order_id},
                        "id": "mock-order-1",
                        "type": "tool_call",
                    }
                ],
            ),
            AIMessage(content="I checked the Olist order lookup."),
        ]
    )
    executor2 = AgentExecutor(
        agent=create_tool_calling_agent(model2, TOOLS, PROMPT),
        tools=TOOLS,
        max_iterations=5,
        return_intermediate_steps=True,
    )
    r2 = executor2.invoke(
        {
            "input": f"Look up order {order_id} and tell me its status, review score and payment value.",
            "chat_history": [],
        }
    )

    # Query 3: combined tools.
    model3 = FakeMessagesListChatModel(
        responses=[
            AIMessage(
                content="",
                tool_calls=[
                    {
                        "name": "get_weather",
                        "args": {"city": "New Delhi"},
                        "id": "mock-combined-weather",
                        "type": "tool_call",
                    }
                ],
            ),
            AIMessage(
                content="",
                tool_calls=[
                    {
                        "name": "lookup_olist_order",
                        "args": {"order_id": order_id},
                        "id": "mock-combined-order",
                        "type": "tool_call",
                    }
                ],
            ),
            AIMessage(content="I checked both the live weather and Olist data."),
        ]
    )
    executor3 = AgentExecutor(
        agent=create_tool_calling_agent(model3, TOOLS, PROMPT),
        tools=TOOLS,
        max_iterations=5,
        return_intermediate_steps=True,
    )
    r3 = executor3.invoke(
        {
            "input": f"What is the weather in New Delhi and what is the status of order {order_id}?",
            "chat_history": [],
        }
    )

    traces = [
        {
            "mode": "mock",
            "query": "What is the current weather in New Delhi?",
            "native_tool_calls": extract_trace(r1),
            "final_answer": r1["output"],
        },
        {
            "mode": "mock",
            "query": f"Look up order {order_id} and tell me its status, review score and payment value.",
            "native_tool_calls": extract_trace(r2),
            "final_answer": r2["output"],
        },
        {
            "mode": "mock",
            "query": f"What is the weather in New Delhi and what is the status of order {order_id}?",
            "native_tool_calls": extract_trace(r3),
            "final_answer": r3["output"],
        },
    ]

    # Also demonstrate the separate conditional workflow.
    traces.append(
        {
            "conditional_workflow": run_both_routes(),
        }
    )

    return {"sample_order_id": order_id, "runs": traces}


def run_live() -> dict:
    """Run the actual Gemini-backed autonomous agent demonstration."""
    order_id = sample_order_id()
    executor = build_executor()
    all_runs = []

    queries = [
        "What is the current weather in New Delhi?",
        f"Look up order {order_id} and tell me its status, review score and payment value.",
        f"What is the weather in New Delhi, and also look up order {order_id}?",
    ]

    for query in queries:
        result, _history, callback_calls = run_live_query(executor, query, [])
        all_runs.append(
            {
                "mode": "live",
                "query": query,
                "native_tool_calls_at_call_time": callback_calls,
                "post_run_intermediate_steps": extract_trace(result),
                "final_answer": result["output"],
            }
        )

    # Two-turn memory demonstration.
    history = []
    turn1, history, turn1_calls = run_live_query(
        executor,
        "Check the weather in New Delhi.",
        history,
    )
    turn2, history, turn2_calls = run_live_query(
        executor,
        "What about the same city again?",
        history,
    )

    memory_demo = {
        "turn_1": {
            "query": "Check the weather in New Delhi.",
            "tool_calls_at_call_time": turn1_calls,
            "post_run_intermediate_steps": extract_trace(turn1),
            "answer": turn1["output"],
        },
        "turn_2": {
            "query": "What about the same city again?",
            "tool_calls_at_call_time": turn2_calls,
            "post_run_intermediate_steps": extract_trace(turn2),
            "answer": turn2["output"],
        },
    }

    return {
        "sample_order_id": order_id,
        "runs": all_runs,
        "memory_demo": memory_demo,
        "conditional_workflow": run_both_routes(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--live", action="store_true", help="Run Gemini-backed agent.")
    parser.add_argument("--mock", action="store_true", help="Run deterministic mock agent.")
    args = parser.parse_args()

    if not args.live and not args.mock:
        parser.error("Choose either --live or --mock.")

    result = run_live() if args.live else run_mock()

    output = Path(__file__).resolve().parents[1] / "outputs" / "demo_trace.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(result, indent=2, ensure_ascii=False, default=str),
        encoding="utf-8",
    )

    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))


if __name__ == "__main__":
    main()
