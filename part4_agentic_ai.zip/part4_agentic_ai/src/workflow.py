from __future__ import annotations

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableBranch, RunnablePassthrough


def build_conditional_workflow():
    """Build a small stateful conditional workflow.

    Step 1 uses RunnablePassthrough.assign to accumulate a classification
    value. Step 2 uses RunnableBranch to select one of two downstream chains.
    """

    classify = RunnablePassthrough.assign(
        priority=lambda state: (
            "high"
            if any(
                word in state["message"].lower()
                for word in ("urgent", "asap", "immediately", "critical")
            )
            else "normal"
        )
    )

    high_prompt = ChatPromptTemplate.from_template(
        "Write a concise high-priority response to: {message}"
    )
    normal_prompt = ChatPromptTemplate.from_template(
        "Write a concise normal-priority response to: {message}"
    )

    # These two downstream chains are intentionally simple and deterministic.
    high_chain = high_prompt | StrOutputParser()
    normal_chain = normal_prompt | StrOutputParser()

    branch = RunnableBranch(
        (lambda state: state["priority"] == "high", high_chain),
        normal_chain,
    )

    return classify | branch


def run_both_routes() -> list[dict[str, str]]:
    workflow = build_conditional_workflow()

    high = workflow.invoke({"message": "This is urgent; please respond ASAP."})
    normal = workflow.invoke({"message": "Please send the monthly report when convenient."})

    return [
        {"input": "This is urgent; please respond ASAP.", "route": "high", "output": high},
        {
            "input": "Please send the monthly report when convenient.",
            "route": "normal",
            "output": normal,
        },
    ]
