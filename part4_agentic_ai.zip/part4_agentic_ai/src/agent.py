from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_google_genai import ChatGoogleGenerativeAI

from .tools import TOOLS

load_dotenv()

SYSTEM_PROMPT = """You are an autonomous data-and-information assistant.

Use tools whenever they are relevant:
- Use get_weather for current weather questions.
- Use lookup_olist_order for questions about an Olist order in the local dataset.

Do not invent tool results. If a tool returns an error, explain the limitation.
Give concise, evidence-based answers.
"""

PROMPT = ChatPromptTemplate.from_messages(
    [
        ("system", SYSTEM_PROMPT),
        MessagesPlaceholder(variable_name="chat_history"),
        ("human", "{input}"),
        MessagesPlaceholder(variable_name="agent_scratchpad"),
    ]
)


class NativeToolDecisionLogger(BaseCallbackHandler):
    """Capture the framework-resolved tool + arguments when a tool starts.

    AgentAction is LangChain's native parsed representation; no raw model text
    or regex/JSON parsing is used.
    """

    def __init__(self) -> None:
        self.calls: list[dict[str, Any]] = []

    def on_agent_action(self, action, **kwargs: Any) -> None:
        tool_input = action.tool_input
        arguments = tool_input if isinstance(tool_input, dict) else {"input": tool_input}
        record = {"tool": action.tool, "arguments": arguments}
        self.calls.append(record)
        print(json.dumps(record, ensure_ascii=False))

    def on_tool_start(self, serialized: dict[str, Any], input_str: str, **kwargs: Any) -> None:
        # Deliberately do not create a second record here. The on_agent_action
        # callback is the authoritative native routing decision.
        return None


def build_executor(callbacks: list[BaseCallbackHandler] | None = None) -> AgentExecutor:
    """Build the bounded LangChain tool-calling agent."""
    api_key = os.getenv("GOOGLE_API_KEY")
    if not api_key:
        raise RuntimeError(
            "GOOGLE_API_KEY is missing. Copy .env.example to .env and add your key."
        )

    model_name = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    llm = ChatGoogleGenerativeAI(
        model=model_name,
        temperature=0,
        google_api_key=api_key,
    )

    agent = create_tool_calling_agent(llm, TOOLS, PROMPT)

    return AgentExecutor(
        agent=agent,
        tools=TOOLS,
        verbose=False,
        max_iterations=5,
        return_intermediate_steps=True,
        handle_parsing_errors=True,
        callbacks=callbacks,
    )


def extract_native_tool_calls(message: BaseMessage) -> list[dict[str, Any]]:
    """Extract LangChain's native AIMessage.tool_calls representation.

    No raw-text JSON parsing or regex parsing is used.
    """
    if not isinstance(message, AIMessage):
        return []

    records: list[dict[str, Any]] = []
    for call in getattr(message, "tool_calls", []) or []:
        records.append(
            {
                "tool": call.get("name"),
                "arguments": call.get("args", {}),
            }
        )
    return records


def extract_trace(result: dict[str, Any]) -> list[dict[str, Any]]:
    """Extract native tool calls from AgentExecutor intermediate steps."""
    trace: list[dict[str, Any]] = []

    for action, _observation in result.get("intermediate_steps", []):
        # AgentAction.tool_input is already parsed by the framework.
        arguments = action.tool_input
        if not isinstance(arguments, dict):
            arguments = {"input": arguments}

        trace.append(
            {
                "tool": action.tool,
                "arguments": arguments,
            }
        )

    # The final AIMessage is also inspected when available.
    output = result.get("output")
    if isinstance(output, AIMessage):
        trace.extend(extract_native_tool_calls(output))

    return trace


def run_live_query(
    executor: AgentExecutor,
    query: str,
    chat_history: list[BaseMessage] | None = None,
) -> tuple[dict[str, Any], list[BaseMessage], list[dict[str, Any]]]:
    """Run one live query and capture native routing decisions at call time."""
    history = list(chat_history or [])
    logger = NativeToolDecisionLogger()

    result = executor.invoke(
        {
            "input": query,
            "chat_history": history,
        },
        config={"callbacks": [logger]},
    )

    updated_history = history + [
        HumanMessage(content=query),
        AIMessage(content=result["output"]),
    ]

    return result, updated_history, logger.calls


def save_trace(trace: list[dict[str, Any]], path: str | Path) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(
        json.dumps(trace, indent=2, ensure_ascii=False, default=str),
        encoding="utf-8",
    )
